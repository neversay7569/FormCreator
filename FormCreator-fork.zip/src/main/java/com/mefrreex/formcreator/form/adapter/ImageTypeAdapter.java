package com.mefrreex.formcreator.form.adapter;

import com.google.gson.annotations.SerializedName;

public enum ImageTypeAdapter {
    @SerializedName("path") PATH,
    @SerializedName("url") URL;
}
