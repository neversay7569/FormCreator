package com.mefrreex.formcreator.form.adapter.handler;

import cn.nukkit.Player;

public interface ButtonHandler {
    void handle(Player player);
}
