package com.mefrreex.formcreator.form.adapter.handler;

import cn.nukkit.Player;

public interface CloseHandler {
    void handle(Player player);
}
