package com.mefrreex.formcreator.form.action.executor;

import cn.nukkit.Player;

public interface Executor {
    
    public void execute(Player player, String value);
}
